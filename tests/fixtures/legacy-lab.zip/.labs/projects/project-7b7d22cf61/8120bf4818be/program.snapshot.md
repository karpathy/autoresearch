Project: project
Goal: improve score
Metric: score, max
