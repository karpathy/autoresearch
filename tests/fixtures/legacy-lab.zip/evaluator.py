import json, sys
from pathlib import Path
candidate, run_dir = map(Path, sys.argv[1:3])
value = int((candidate / 'value.txt').read_text())
run_dir.mkdir(parents=True, exist_ok=True)
(run_dir / 'result.json').write_text(json.dumps({'metrics': {'score': value}, 'usage': {'requests': 0, 'cost_usd': 0}}))
