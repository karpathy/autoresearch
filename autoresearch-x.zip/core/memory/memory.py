class Memory:
    def __init__(self):
        self.short_term = []

    def store_short(self, data):
        self.short_term.append(data)
