class PerceptionEngine:
    def ingest(self, text):
        return {
            "raw": text,
            "entities": list(set(text.split())),
            "relations": []
        }
