class Reasoner:
    def generate_hypotheses(self, graph):
        concepts = graph.get_concepts()
        if len(concepts) < 2:
            return []
        return [
            f"{concepts[0]} influences {concepts[1]}",
            f"{concepts[1]} depends on {concepts[0]}"
        ]
