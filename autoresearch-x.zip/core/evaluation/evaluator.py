import random

class Evaluator:
    def evaluate(self, hypothesis):
        confidence = round(random.uniform(0.4, 0.9), 2)
        state = "known" if confidence > 0.75 else "inferred" if confidence > 0.5 else "uncertain"
        return {"hypothesis": hypothesis, "confidence": confidence, "state": state}
