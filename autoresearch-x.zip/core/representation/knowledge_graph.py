import networkx as nx

class KnowledgeGraph:
    def __init__(self):
        self.graph = nx.DiGraph()

    def add_concept(self, concept):
        self.graph.add_node(concept, confidence=0.5)

    def get_concepts(self):
        return list(self.graph.nodes)
