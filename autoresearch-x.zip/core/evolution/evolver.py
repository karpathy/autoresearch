class Evolver:
    def update(self, evaluations):
        strong = [e for e in evaluations if e["confidence"] > 0.7]
        return "Strategy reinforced" if strong else "Strategy adjusted"
