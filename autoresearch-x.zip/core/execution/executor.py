class Executor:
    def execute(self, evaluations):
        return "\n".join([f"{e['hypothesis']} → {e['state']} ({e['confidence']})" for e in evaluations])
