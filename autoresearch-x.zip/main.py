from core.perception.ingest import PerceptionEngine
from core.representation.knowledge_graph import KnowledgeGraph
from core.reasoning.reasoner import Reasoner
from core.evaluation.evaluator import Evaluator
from core.memory.memory import Memory
from core.evolution.evolver import Evolver
from core.execution.executor import Executor

def cognitive_cycle(input_text):
    perception = PerceptionEngine()
    graph = KnowledgeGraph()
    reasoner = Reasoner()
    evaluator = Evaluator()
    memory = Memory()
    evolver = Evolver()
    executor = Executor()

    perceived = perception.ingest(input_text)

    for entity in perceived["entities"]:
        graph.add_concept(entity)

    hypotheses = reasoner.generate_hypotheses(graph)

    evaluations = []
    for h in hypotheses:
        eval_result = evaluator.evaluate(h)
        evaluations.append(eval_result)

    memory.store_short(evaluations)

    strategy = evolver.update(evaluations)

    report = executor.execute(evaluations)

    return {
        "report": report,
        "strategy": strategy
    }

if __name__ == "__main__":
    query = input("Enter research topic: ")
    result = cognitive_cycle(query)

    print("\n--- REPORT ---")
    print(result["report"])

    print("\n--- SYSTEM EVOLUTION ---")
    print(result["strategy"])
